import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

from retrieval import retrieve_contexts
from embedding import embed_text
from forecast import call_forecast
from llm import generate_answer
from forecast import call_forecast, get_forecast_df


# ──────────── Config ────────────
PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT", "emerging-talent-group")
BQ_DATASET = os.getenv("BQ_DATASET", "propwise_embeddings")
BQ_TABLE = os.getenv("BQ_TABLE", "zone_snapshots")
AUTOML_FORECAST_URL = os.getenv("AUTOML_FORECAST_URL", "")
TOP_K = int(os.getenv("TOP_K", "5"))

# ──────────── App Setup ────────────
app = FastAPI(title="PropWise Advisor")

# CORS Middleware for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with specific Streamlit URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ──────────── Request + Response Models ────────────
class ChatRequest(BaseModel):
    session_id: str
    query: str
    area_code: str

class ChatResponse(BaseModel):
    reply: str

class FeedbackRequest(BaseModel):
    session_id: str
    query: str
    response: str
    rating: int

# ──────────── Lifecycle Events ────────────
@app.on_event("startup")
def startup_event():
    print("✅ PropWise API started.")

@app.on_event("shutdown")
def shutdown_event():
    print("🛑 PropWise API shutting down.")

# ──────────── Chat Endpoint ────────────
from fastapi.responses import JSONResponse
from forecast import call_forecast, get_forecast_df
import numpy as np

def to_native(val):
    if isinstance(val, (np.integer, np.int64, np.int32)):
        return int(val)
    elif isinstance(val, (np.floating, np.float64, np.float32)):
        return float(val)
    return val

@app.post("/chat")
def chat(req: ChatRequest):
    try:
        q_vec = embed_text(req.query)
        contexts = retrieve_contexts(PROJECT_ID, BQ_DATASET, BQ_TABLE, q_vec, TOP_K)

        if not contexts:
            return {"reply": "Sorry, no relevant info found."}

        forecast_snip = call_forecast(req.area_code)
        
        # Fix: Join contexts first to avoid backslash in f-string expression
        joined_contexts = '\n\n---\n\n'.join(contexts)
        
        prompt = (
            f"You are a UK property advisor. {forecast_snip}\n\n"
            f"{joined_contexts}\n\nUser Question: {req.query}"
        )

        answer = generate_answer(prompt)

        forecast_df = get_forecast_df(req.area_code)
        latest = forecast_df.iloc[-1] if not forecast_df.empty else {}

        return {
            "reply": answer,
            "forecast_appreciation": to_native(latest.get("forecast_appreciation", None)),
            "initial_price": to_native(latest.get("initial_price", None)),
            "sdlt_first_time": to_native(latest.get("SDLT_first_time", None))
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ──────────── Feedback Endpoint ────────────
from reward_model import PropWiseRewardModel

@app.post("/feedback")
def feedback(fb: FeedbackRequest):
    from google.cloud import bigquery
    from datetime import datetime

    print(f"\n📥 Feedback received for session {fb.session_id}")
    client = bigquery.Client(project=PROJECT_ID)
    table_id = f"{PROJECT_ID}.{BQ_DATASET}.advisor_feedback"

    # Score from reward model
    reward_model = PropWiseRewardModel()
    reward_score = reward_model.score({
        "query": fb.query,
        "response": fb.response,
        "rating": fb.rating,
        "area_code": fb.session_id  # Or use real area_code if passed
    })

    row = [{
        "session_id": fb.session_id,
        "query": fb.query,
        "response": fb.response,
        "rating": fb.rating,
        "area_code": fb.session_id,  # You can modify this
        "timestamp": datetime.utcnow().isoformat(),
        "created_at": datetime.utcnow().isoformat(),
        "reward_score": reward_score  # Add this column to BigQuery if needed
    }]
    errors = client.insert_rows_json(table_id, row)
    if errors:
        print(f"❌ Failed to store feedback: {errors}")
        raise HTTPException(500, f"Failed to write feedback: {errors}")

    print("✅ Feedback stored.")
    return {"status": "ok", "reward_score": reward_score}

# ──────────── Healthcheck ────────────
@app.get("/health")
def health():
    return {"status": "ok"}

# ──────────── Local Development ────────────
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8080))
    #uvicorn.run("main:app", host="0.0.0.0", port=8601, reload=True)
    uvicorn.run("main:app", host="0.0.0.0", port=port, log_level="info")

