import gradio as gr
import pandas as pd
import plotly.graph_objs as go
import requests
import os

# ========================
# 📊 LOAD FORECAST DATA
# ========================
df = pd.read_csv("prediction.csv", parse_dates=["Date"])
area_codes = sorted(df["AreaCode"].dropna().unique())
region_names = sorted(df["RegionName_x"].dropna().unique())

# ========================
# ⚙️ CONFIG
# ========================
API_URL = os.getenv("PROPWISE_API_URL", "https://propwise-backend-791135088593.us-central1.run.app/chat")

THEME = gr.themes.Soft(
    primary_hue="cyan", secondary_hue="cyan", neutral_hue="slate"
).set(
    body_background_fill="linear-gradient(180deg,#0d1a24,#000)",
    block_background_fill="#0d1a24",
    border_color_primary="#0ff",
    block_shadow="0 0 24px rgba(0,255,255,0.2)",
)

# ========================
# 🤖 AI CHATBOT FUNCTION
# ========================
def propwise_chat(user_question: str, area_code: str):
    if not user_question.strip():
        return ("⚠️ *Please enter a question.*", go.Figure(), go.Figure(), go.Figure())

    payload = {
        "query": user_question,
        "session_id": "web-user",
        "area_code": area_code or "E1",
    }

    try:
        resp = requests.post(API_URL, json=payload, timeout=60)
        resp.raise_for_status()
        data = resp.json()

        chat_md = f"**You:** {user_question}\n\n**PropWise:** {data.get('reply', '_no reply_')}"

        area_df = df[df["AreaCode"] == area_code].sort_values("Date")
        if area_df.empty:
            return (chat_md, go.Figure(), go.Figure(), go.Figure())

        # Initial & Predicted Price Line Graph
        fig_price = go.Figure()
        fig_price.add_trace(go.Scatter(x=area_df["Date"], y=area_df["initial_price"], name="Initial Price"))
        fig_price.add_trace(go.Scatter(x=area_df["Date"], y=area_df["predicted_AveragePrice"], name="Predicted Price"))
        fig_price.update_layout(template="plotly_dark")

        # Appreciation % Bar Graph
        fig_gain = go.Figure()
        fig_gain.add_trace(go.Bar(x=area_df["Date"], y=area_df["forecast_appreciation"], name="Appreciation"))
        fig_gain.update_layout(template="plotly_dark")

        # FTB SDLT Line Graph
        fig_sdlt = go.Figure()
        fig_sdlt.add_trace(go.Scatter(x=area_df["Date"], y=area_df["SDLT_first_time"], name="FTB SDLT"))
        fig_sdlt.update_layout(template="plotly_dark")

        return chat_md, fig_price, fig_gain, fig_sdlt

    except Exception as e:
        return (f"❌ **Error:** {e}", go.Figure(), go.Figure(), go.Figure())

# ========================
# 📈 LINE GRAPH (AREA)
# ========================
def line_graph_by_area(area_code):
    area = df[df["AreaCode"] == area_code].sort_values("Date")
    fig = go.Figure()
    if not area.empty:
        fig.add_trace(go.Scatter(x=area["Date"], y=area["initial_price"], name="Initial Price"))
        fig.add_trace(go.Scatter(x=area["Date"], y=area["predicted_AveragePrice"], name="Predicted Price"))
    fig.update_layout(title=f"📈 Price Trends – {area_code}", template="plotly_dark")
    return fig

# ========================
# 📊 BAR GRAPH (AREA)
# ========================
def bar_graph_by_area(area_code):
    area = df[df["AreaCode"] == area_code].sort_values("Date")
    fig = go.Figure()
    if not area.empty:
        fig.add_trace(go.Bar(x=area["Date"], y=area["forecast_appreciation"], name="Appreciation (%)"))
    fig.update_layout(title=f"📊 Appreciation – {area_code}", yaxis_title="%", template="plotly_dark")
    return fig

# ========================
# 📈 REGION VISUALIZATION
# ========================
def line_graph_by_region(region_name):
    region = df[df["RegionName_x"] == region_name].groupby("Date")[["initial_price", "predicted_AveragePrice"]].mean().reset_index()
    fig = go.Figure()
    if not region.empty:
        fig.add_trace(go.Scatter(x=region["Date"], y=region["initial_price"], name="Avg Initial Price"))
        fig.add_trace(go.Scatter(x=region["Date"], y=region["predicted_AveragePrice"], name="Avg Predicted Price"))
    fig.update_layout(title=f"📈 Regional Price Trend – {region_name}", template="plotly_dark")
    return fig

def bar_graph_by_region(region_name):
    region = df[df["RegionName_x"] == region_name].groupby("Date")[["forecast_appreciation"]].mean().reset_index()
    fig = go.Figure()
    if not region.empty:
        fig.add_trace(go.Bar(x=region["Date"], y=region["forecast_appreciation"], name="Avg Appreciation"))
    fig.update_layout(title=f"📊 Regional Appreciation – {region_name}", yaxis_title="%", template="plotly_dark")
    return fig

def send_feedback(session_id, query, response, rating):
    try:
        payload = {
            "session_id": session_id,
            "query": query,
            "response": response,
            "rating": int(rating)
        }
        feedback_url = os.getenv("PROPWISE_FEEDBACK_URL", "https://propwise-backend-791135088593.us-central1.run.app/feedback")
        r = requests.post(feedback_url, json=payload)
        return "✅ Feedback submitted!" if r.status_code == 200 else "❌ Error"
    except Exception as e:
        return f"❌ {e}"

# ========================
# 🖥️ GRADIO APP
# ========================
# Custom CSS for scrollable chatbox
css = """
.scrollable-chat {
    max-height: 400px !important;
    overflow-y: auto !important;
    padding: 15px !important;
    border: 1px solid #0ff !important;
    border-radius: 8px !important;
    background-color: #0d1a24 !important;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif !important;
    line-height: 1.5 !important;
}

.scrollable-chat::-webkit-scrollbar {
    width: 8px !important;
}

.scrollable-chat::-webkit-scrollbar-track {
    background: #1a2332 !important;
    border-radius: 4px !important;
}

.scrollable-chat::-webkit-scrollbar-thumb {
    background: #0ff !important;
    border-radius: 4px !important;
}

.scrollable-chat::-webkit-scrollbar-thumb:hover {
    background: #00cccc !important;
}
"""

with gr.Blocks(theme=THEME, title="PropWise – UK Property Advisor", css=css) as demo:
    gr.Markdown("<h1 style='text-align:center; color:#0ff;'>🏡 PropWise Dashboard</h1>")

    with gr.Tabs():
        # Tab 1: Chatbot
        with gr.TabItem("💬 AI Property Advisor"):
            with gr.Row():
                with gr.Column(scale=1.5):
                    chatbox = gr.Markdown(
                        "👋 *Ask about UK property...*",
                        elem_classes="scrollable-chat"
                    )
                    user_q = gr.Textbox(label="💬 Your Question", lines=3)
                    area_in = gr.Textbox(label="📍 Area Code", value="E1")
                    ask_btn = gr.Button("🔮 Ask PropWise")
                    rating_slider = gr.Slider(minimum=1, maximum=5, step=1, label="Rate the Response")
                    submit_feedback = gr.Button("📩 Submit Feedback")
                    session_state = gr.Textbox(value="web-user", visible=False, interactive=False)

                with gr.Column(scale=1):
                    chatbot_line_plot = gr.Plot(label="📈 Initial & Predicted Price")
                    chatbot_gain_plot = gr.Plot(label="📊 Forecast Appreciation (%)")
                    chatbot_sdlt_plot = gr.Plot(label="🧾 FTB SDLT Over Time")

            ask_btn.click(
                fn=propwise_chat,
                inputs=[user_q, area_in],
                outputs=[
                    chatbox,
                    chatbot_line_plot,
                    chatbot_gain_plot,
                    chatbot_sdlt_plot,
                ],
            )
            
            submit_feedback.click(
                fn=send_feedback,
                inputs=[session_state, user_q, chatbox, rating_slider],
                outputs=[chatbox],
            )

        # Tab 2: Area-Based Forecast Graphs
        with gr.TabItem("📊 Forecast by AreaCode"):
            with gr.Row():
                area_select = gr.Dropdown(label="Select Area Code", choices=area_codes, value=area_codes[0])
            with gr.Row():
                line_plot_area = gr.Plot(label="📈 Price Trends")
                bar_plot_area = gr.Plot(label="📊 Appreciation %")

            area_select.change(fn=line_graph_by_area, inputs=area_select, outputs=line_plot_area)
            area_select.change(fn=bar_graph_by_area, inputs=area_select, outputs=bar_plot_area)

            demo.load(fn=line_graph_by_area, inputs=[area_select], outputs=[line_plot_area])
            demo.load(fn=bar_graph_by_area, inputs=[area_select], outputs=[bar_plot_area])

        # Tab 3: Region-Based Forecast Graphs
        with gr.TabItem("📍 Forecast by Region"):
            with gr.Row():
                region_select = gr.Dropdown(label="Select Region", choices=region_names, value=region_names[0])
            with gr.Row():
                line_plot_region = gr.Plot(label="📈 Avg Prices by Region")
                bar_plot_region = gr.Plot(label="📊 Avg Appreciation by Region")

            region_select.change(fn=line_graph_by_region, inputs=region_select, outputs=line_plot_region)
            region_select.change(fn=bar_graph_by_region, inputs=region_select, outputs=bar_plot_region)

            demo.load(fn=line_graph_by_region, inputs=[region_select], outputs=[line_plot_region])
            demo.load(fn=bar_graph_by_region, inputs=[region_select], outputs=[bar_plot_region])

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=8600)
