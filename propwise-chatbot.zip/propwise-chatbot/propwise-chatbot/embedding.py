from vertexai import init
from vertexai.language_models import TextEmbeddingModel

init(project="emerging-talent-group", location="us-central1")

def embed_text(text: str) -> list[float]:
    embed_model = TextEmbeddingModel.from_pretrained("gemini-embedding-001")  # moved here
    resp = embed_model.get_embeddings([text])
    return resp[0].values
