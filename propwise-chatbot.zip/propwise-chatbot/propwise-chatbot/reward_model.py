class PropWiseRewardModel:
    def __init__(self, weights=None):
        # You can adjust weights to prioritize rating, area relevance, etc.
        self.weights = weights or {
            "rating": 1.0,
            "area_code_match": 0.5
        }

    def score(self, feedback: dict) -> float:
        rating = feedback.get("rating", 0)
        area_code = feedback.get("area_code")
        query = feedback.get("query", "").lower()
        response = feedback.get("response", "").lower()

        area_match = 1 if area_code.lower() in response else 0

        score = (
            rating * self.weights["rating"]
            + area_match * self.weights["area_code_match"]
        )
        return round(score, 2)
