import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="vertexai.generative_models._generative_models")
from vertexai.preview.generative_models import GenerativeModel

llm = GenerativeModel("gemini-2.0-flash-001")

def generate_answer(prompt: str, max_tokens: int = 512) -> str:
    print("🧪 Prompt sent to Gemini:")
    print(prompt)
    response = llm.generate_content(
        prompt,
        generation_config={
            "max_output_tokens": max_tokens,
            "temperature": 0.0,
            "top_k": 40,
            "top_p": 0.95,
        }
    )
    print("🧠 Gemini response received.")
    return response.text.strip()
