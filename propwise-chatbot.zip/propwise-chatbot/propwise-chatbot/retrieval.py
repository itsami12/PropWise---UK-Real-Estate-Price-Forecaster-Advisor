from google.cloud import bigquery

def get_bigquery_client(project_id: str):
    return bigquery.Client(project=project_id, location="US")

def retrieve_contexts(project_id: str, dataset: str, table: str, query_vec: list, k: int = 5) -> list[str]:
    client = get_bigquery_client(project_id)

    vec_str = ",".join(str(x) for x in query_vec)
    print("📤 Running BigQuery retrieval...")

    sql = f"""
    WITH query_embedding AS (
      SELECT ARRAY[{vec_str}] AS q
    ),
    distances AS (
      SELECT
        t.snapshot_text,
        (
          SELECT SUM(POW(e - qv, 2))
          FROM UNNEST(t.embedding) AS e WITH OFFSET i,
               UNNEST(query_embedding.q) AS qv WITH OFFSET j
          WHERE i = j
        ) AS l2_distance
      FROM `{project_id}.{dataset}.{table}` AS t, query_embedding
    )
    SELECT snapshot_text
    FROM distances
    ORDER BY l2_distance ASC
    LIMIT {k};
    """
    print("📄 SQL QUERY:")
    print(sql)

    try:
        rows = client.query(sql).result()
        result = [row.snapshot_text for row in rows]
        print(f"📦 Retrieved {len(result)} context snippets.")
        return result
    except Exception as e:
        print(f"❌ BigQuery query failed: {e}")
        raise
