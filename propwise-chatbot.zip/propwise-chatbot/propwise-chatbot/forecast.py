# forecast.py
import pandas as pd
import os
import plotly.graph_objs as go

CSV_PATH = 'prediction.csv'
df = pd.read_csv(CSV_PATH, parse_dates=["Date"])

def call_forecast(area_code: str) -> str:
    """Returns a summary string of the latest forecast values for a given area."""
    area_data = df[df["AreaCode"] == area_code].sort_values("Date")
    if area_data.empty:
        return "No forecast data available for this area."

    latest = area_data.iloc[-1]
    appreciation = latest.get("forecast_appreciation", 0)
    price = latest.get("initial_price", 0)
    sdlt = latest.get("SDLT_first_time", 0)

    return (
        f"Latest price: £{price:,.0f}, "
        f"Forecast appreciation: {appreciation}%, "
        f"First-time buyer SDLT: £{sdlt:,.0f}"
    )

def get_forecast_df(area_code: str):
    return df[df["AreaCode"] == area_code].sort_values("Date")

def plot_forecast(area_code: str):
    area_data = get_forecast_df(area_code)
    if area_data.empty:
        return go.Figure()

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=area_data["Date"], y=area_data["initial_price"], name="Initial Price"))
    fig.add_trace(go.Scatter(x=area_data["Date"], y=area_data["predicted_AveragePrice"], name="Forecasted Price"))
    fig.add_trace(go.Scatter(x=area_data["Date"], y=area_data["forecast_appreciation"], name="Forecast Appreciation (%)", yaxis="y2"))

    fig.update_layout(
        title=f"📊 Property Price Forecast – {area_code}",
        xaxis_title="Date",
        yaxis=dict(title="£ Price"),
        yaxis2=dict(title="% Appreciation", overlaying="y", side="right"),
        template="plotly_dark"
    )
    return fig
